# scnet-connector

SSH 连接到 SCNet 超算集群。

## 用法
```bash
scnet-connect --user <用户名> --host <主机> [--port <端口>] [--key <密钥>]
```

## 示例
```bash
scnet-connect -u scntwbdhgf -h cancon.hpccube.com -p 65023 -k ~/Downloads/key.txt
```